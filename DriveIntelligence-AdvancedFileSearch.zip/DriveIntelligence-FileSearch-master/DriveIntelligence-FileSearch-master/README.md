# DriveIntelligence-FileSearch
Basic code for searching files in all drives. In comments there is code to upload file to remote php server but not finished.
